package com.sham.demoregistration.model;

/**
 * Created by Sunil on 04/13/2018.
 */

public class UserData {

    String name;
    String phone;
    String Email;
    String password;

    public UserData(String name, String phone, String email, String password) {
        this.name = name;
        this.phone = phone;
        this.Email = email;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
