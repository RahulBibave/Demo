package com.sham.demoregistration.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.sham.demoregistration.R;

/**
 * Created by Sunil on 04/13/2018.
 */

public class HomeActivity extends AppCompatActivity {

    TextView txt_Name,txt_Phone,txt_email;
    String name,phone,email;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);
        init();
        Intent intent=getIntent();
        name=intent.getStringExtra("NAME");
        phone=intent.getStringExtra("PHONE");
        email=intent.getStringExtra("EMAIL");

        if (name!=null){
            txt_Name.setText("Welcome "+name+"!");
        }

        if (email!=null){
            txt_email.setText("Email ID: "+email);
        }
        if (phone!=null){
            txt_Phone.setText("Phone No: "+phone);
        }
    }

    public void init(){
        txt_Name=(TextView)findViewById(R.id.txt_welcome);
        txt_email=(TextView)findViewById(R.id.txt_Email);
        txt_Phone=(TextView)findViewById(R.id.txt_Phone);
    }
}
