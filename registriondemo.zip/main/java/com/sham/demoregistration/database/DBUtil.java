package com.sham.demoregistration.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.sham.demoregistration.model.UserData;

import java.util.ArrayList;

/**
 * Created by Sunil on 04/13/2018.
 */

public class DBUtil {

    private static DBUtil dbUtil;
    private static SQLiteDatabase db;

    static {
        dbUtil=null;
    }



    public static DBUtil getInstance(Context context){
        if (dbUtil==null){
            return new DBUtil(context,1);
        }
        return dbUtil;
    }

    private DBUtil(Context context, int version) {
        db=new MyDBHelper(context,"c_db",null,version).getWritableDatabase();
    }

    public boolean saveUserDetail(String name,String phone,String email,String password){
        ContentValues values=new ContentValues();
        values.put("userName",name);
        values.put("phoneNo",phone);
        values.put("emailID",email);
        values.put("password",password);
        return InsertDataIntoTable("UserDetail",values);
    }


    public ArrayList<UserData> getAllUSerData(){
        ArrayList<UserData> listOFAllUser=new ArrayList<>();
        Cursor cursor=db.rawQuery("Select * from UserDetail",null);
        if (cursor.moveToFirst()){
            do {
                String name=cursor.getString(cursor.getColumnIndex("userName"));
                String phone=cursor.getString(cursor.getColumnIndex("phoneNo"));
                String emailID=cursor.getString(cursor.getColumnIndex("emailID"));
                String password=cursor.getString(cursor.getColumnIndex("password"));
                UserData userData=new UserData(name,phone,emailID,password);
                listOFAllUser.add(userData);
            }while (cursor.moveToNext());
        }
        return listOFAllUser;

    }
    public boolean InsertDataIntoTable(String tableName,ContentValues values){
        long count=db.insert(tableName, (String) null, values);
        if(count>0){
            Log.e("Success", "Inserted into :" + tableName);
            return true;
        } else {
            Log.e("Failure", "To insert into" + tableName);
            return false;
        }
    }
}
