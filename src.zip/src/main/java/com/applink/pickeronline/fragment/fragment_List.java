package com.applink.pickeronline.fragment;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applink.pickeronline.R;
import com.applink.pickeronline.adapters.Categories_Adapter;
import com.applink.pickeronline.models.Cateories;
import com.applink.pickeronline.utils.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Sunil on 3/9/2018.
 */

public class fragment_List extends Fragment {
    RecyclerView recycler_Catrgoris;
    ArrayList<Cateories> listOFAllCategories;
    Categories_Adapter categories_adapter;
    ProgressDialog progressDialog;
    SharedPreferences sharedpreferences;
    String iUserId,tokan;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        listOFAllCategories=new ArrayList<>();
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_list,container,false);
        init(view);
        getAllCategories();
        return view;
    }

    public void init(View view){
        sharedpreferences = getActivity().getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getString(Constants.KEY_USERID, "");
        tokan=sharedpreferences.getString(Constants.KEY_USERTOCKEN,"");
        Log.e("token",""+iUserId+" "+tokan);
        recycler_Catrgoris=(RecyclerView)view.findViewById(R.id.recycler_Categories);
        recycler_Catrgoris.setLayoutManager(new GridLayoutManager(getActivity(),3));

    }

    public void getAllCategories(){
        String url= Constants.MAIN_URL+"api/category";
        RequestQueue requestQueue= Volley.newRequestQueue(getActivity());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        listOFAllCategories.clear();
                        int msg_Code;
                        Log.e("RESPONCEEEEEEEEEE",""+response);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            msg_Code=jsonObject.getInt("message_code");
                            JSONArray jsonArray_Result=jsonObject.getJSONArray("message_text");
                            for (int i=0;i<jsonArray_Result.length();i++){
                                JSONObject jsonObject_Result=jsonArray_Result.getJSONObject(i);
                                String id=jsonObject_Result.getString("ID");
                                String title=jsonObject_Result.getString("title");
                                String image=jsonObject_Result.getString("image");
                                Cateories cateories=new Cateories(id,title,image);
                                listOFAllCategories.add(cateories);
                            }
                            categories_adapter=new Categories_Adapter(getActivity(),listOFAllCategories);
                            recycler_Catrgoris.setAdapter(categories_adapter);
                            categories_adapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Log.e("ERORRRRRRR",""+error);
                        }
                }){ @Override
        public Map<String, String> getHeaders() throws AuthFailureError {
            Map<String,String> headers =new HashMap < String, String > ();
            String credentials = iUserId+":"+tokan;
            String auth = "Basic "
                    + Base64.encodeToString(credentials.getBytes(),
                    Base64.NO_WRAP);
            headers.put("Authorization", auth);
            return headers;
        }

        };
        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
        progressDialog=new ProgressDialog(getActivity());
        progressDialog.setMessage("Please Wait....");
        progressDialog.setProgressStyle(progressDialog.STYLE_SPINNER);
        progressDialog.show();

    }




}
