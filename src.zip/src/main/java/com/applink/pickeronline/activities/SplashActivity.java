package com.applink.pickeronline.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.view.WindowManager;

import com.applink.pickeronline.utils.Constants;

/**
 * Created by Sunil on 3/9/2018.
 */

public class SplashActivity extends AppCompatActivity {
    SharedPreferences sharedpreferences;
    String status,executive;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedpreferences = getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
        status = sharedpreferences.getString(Constants.KEY_USERSTATUS, "");
        executive=sharedpreferences.getString(Constants.KEY_USEREXECUTIVELOGIN,"");
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (executive.equalsIgnoreCase("Enable")){
                    Intent intent=new Intent(SplashActivity.this,ExecutiveHomeActivity.class);
                    startActivity(intent);
                    finish();
                }
                else if (status.equalsIgnoreCase("Enable")){
                    Intent intent=new Intent(SplashActivity.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    Intent intent=new Intent(SplashActivity.this,LoginActivity.class);
                    startActivity(intent);
                    finish();
                }

            }
        },2000);
    }
}
