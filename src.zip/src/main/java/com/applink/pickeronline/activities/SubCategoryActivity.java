package com.applink.pickeronline.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applink.pickeronline.R;
import com.applink.pickeronline.adapters.Categories_Adapter;
import com.applink.pickeronline.adapters.SubCategories_Adapter;
import com.applink.pickeronline.models.Cateories;
import com.applink.pickeronline.models.SubCategories;
import com.applink.pickeronline.utils.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Sunil on 3/12/2018.
 */

public class SubCategoryActivity extends AppCompatActivity {
    RecyclerView recycler_SubCategory;
    SubCategories_Adapter subCategories_adapter;
    ArrayList<SubCategories> listOfSubCat;
    ProgressDialog progressDialog;
    String cat_ID;
    String iUserId,tokan;
    SharedPreferences sharedpreferences;
    private TextView txt_Header;
    private LinearLayout img_backArrow;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sub_category_activity);
        listOfSubCat=new ArrayList<>();
        init();
        Intent intent=getIntent();
        cat_ID=intent.getStringExtra("CAT_ID");
        Constants.Cat_Id=cat_ID;
        txt_Header.setText(intent.getStringExtra("CAT_NAME"));
        getAllSub_Categories();
        img_backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public void init(){
        sharedpreferences = getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getString(Constants.KEY_USERID, "");
        tokan=sharedpreferences.getString(Constants.KEY_USERTOCKEN,"");
        recycler_SubCategory=(RecyclerView)findViewById(R.id.recycler_Sub_Categories);
        txt_Header=findViewById(R.id.txt_Header);
        recycler_SubCategory.setLayoutManager(new GridLayoutManager(SubCategoryActivity.this,2));
        img_backArrow=findViewById(R.id.img_backArrow);
    }


    public void getAllSub_Categories(){
        String url= Constants.MAIN_URL+"api/category/get_child_categories/"+cat_ID;
        RequestQueue requestQueue= Volley.newRequestQueue(SubCategoryActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        listOfSubCat.clear();
                        int msg_Code;
                        Log.e("RESPONCEEEEEEEEEE_SUBCat",""+response);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            msg_Code=jsonObject.getInt("message_code");
                            JSONArray jsonArray_Result=jsonObject.getJSONArray("message_text");
                            for (int i=0;i<jsonArray_Result.length();i++){
                                JSONObject jsonObject_Result=jsonArray_Result.getJSONObject(i);
                                String id=jsonObject_Result.getString("ID");
                                String title=jsonObject_Result.getString("title");
                                String image=jsonObject_Result.getString("image");
                               SubCategories cateories=new SubCategories(id,title,image);
                                listOfSubCat.add(cateories);
                            }
                            subCategories_adapter=new SubCategories_Adapter(SubCategoryActivity.this,listOfSubCat);
                            recycler_SubCategory.setAdapter(subCategories_adapter);
                            subCategories_adapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Log.e("ERORRRRRRR",""+error);

                    }
                }){
             @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> headers =new HashMap< String, String >();;
                String credentials = iUserId+":"+tokan;
                String auth = "Basic "
                        + Base64.encodeToString(credentials.getBytes(),
                        Base64.NO_WRAP);
                headers.put("Authorization", auth);
                return headers;


            };

        };

        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
        progressDialog=new ProgressDialog(SubCategoryActivity.this);
        progressDialog.setMessage("Please Wait....");
        progressDialog.setProgressStyle(progressDialog.STYLE_SPINNER);
        progressDialog.show();

    }
}
