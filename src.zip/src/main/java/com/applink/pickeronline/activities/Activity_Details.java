package com.applink.pickeronline.activities;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.applink.pickeronline.R;
import com.applink.pickeronline.models.Search;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by rahul on 22/3/18.
 */

public class Activity_Details extends AppCompatActivity {
    ArrayList<Search>arrayList;
    private ImageView imageView;
    LinearLayout img_backArrow;
    int pos;
    private RatingBar mRatingBar;
    private TextView mTxtTital,mTxtCityName,mTxtAddress,mTxtPincode;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lay_child_categories_details);
        init();
        img_backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void init() {
        arrayList= (ArrayList<Search>) getIntent().getSerializableExtra("Details");
        pos=getIntent().getIntExtra("pos",1);
        imageView=findViewById(R.id.img_detail);
        mRatingBar=findViewById(R.id.ratingbar_details);
        mTxtTital=findViewById(R.id.txt_deatil_tital);
        mTxtCityName=findViewById(R.id.txtCityName);
        mTxtAddress=findViewById(R.id.txtAddress);
        mTxtPincode=findViewById(R.id.txtPinCode);
        img_backArrow=findViewById(R.id.img_backArrow);

        try {
            Picasso.with(this).load("http://www.pickeronline.in/"+arrayList.get(pos).getImage()).skipMemoryCache().placeholder(R.drawable.placeholder).into(imageView);

        } catch (Exception ex) {

        }
        mTxtTital.setText(arrayList.get(pos).getTitle());
        mTxtPincode.setText(arrayList.get(pos).getPincode());
        mTxtAddress.setText(arrayList.get(pos).getAddress());
        mTxtCityName.setText(arrayList.get(pos).getCity_name());
        try {
            mRatingBar.setRating(Float.parseFloat(arrayList.get(pos).getRating()));
        }catch (NumberFormatException e){
            e.printStackTrace();
        }
    }
}
