package com.applink.pickeronline.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.util.PatternsCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applink.pickeronline.R;
import com.applink.pickeronline.utils.CommonUI;
import com.applink.pickeronline.utils.Constants;
import com.applink.pickeronline.utils.LoginData;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Sunil on 3/9/2018.
 */

public class RegistrationActivity extends AppCompatActivity {
    Button btn_Continue;
    ProgressDialog progressDialog;
    EditText edt_Name,edt_Email,edt_Mobile;
    LinearLayout img_backArrow;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_activity);
        init();

        btn_Continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validation()){
                    if (CommonUI.isNetworkAvailable(RegistrationActivity.this)){
                        RegisterUser();
                    }
                    else {
                        CommonUI.showAlert(RegistrationActivity.this,getString(R.string.app_name),getString(R.string.network_error));
                    }

                }

                /*Intent intent=new Intent(RegistrationActivity.this,OtpVerificationActivity.class);
                startActivity(intent);*/
            }
        });
        img_backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public void init(){
        btn_Continue=(Button)findViewById(R.id.btn_Continue);
        edt_Name=(EditText)findViewById(R.id.edt_Name);
        edt_Email=(EditText)findViewById(R.id.edt_EmailID);
        edt_Mobile=(EditText)findViewById(R.id.edt_MobileNo);
        img_backArrow=findViewById(R.id.img_backArrow);
    }


    public void RegisterUser(){
        Log.e("Emailid***********",""+edt_Email.getText().toString().trim());
        Log.e("Mobile************",""+edt_Mobile.getText().toString().trim());
        Log.e("Name*************",""+edt_Name.getText().toString().trim());


        String url= Constants.MAIN_URL+"registration";
        RequestQueue requestQueue= Volley.newRequestQueue(RegistrationActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressDialog.dismiss();

                        int code;
                        String msg;
                        Log.e("RESPONCEEEEEEEE_DONE REQUEST****",""+response);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            code=jsonObject.getInt("message_code");
                            msg=jsonObject.getString("message_text");


                            if (code==1000){
                                JSONObject jsonObject_Result=jsonObject.getJSONObject("message_text");

                                LoginData.id=jsonObject_Result.getString("ID");
                                LoginData.userName=jsonObject_Result.getString("userName");
                                LoginData.userEmail=jsonObject_Result.getString("userEmail");
                                LoginData.userMobileNo=jsonObject_Result.getString("userMobileNo");
                                LoginData.userPassword=jsonObject_Result.getString("userPassword");
                                LoginData.userTocken=jsonObject_Result.getString("userTocken");
                                LoginData.userOtp=jsonObject_Result.getString("userOtp");
                                LoginData.userStatus=jsonObject_Result.getString("userStatus");
                                LoginData.created=jsonObject_Result.getString("created");
                                LoginData.modified=jsonObject_Result.getString("modified");
                                LoginData.categories=jsonObject_Result.getString("categories");

                                LoginData.radius=jsonObject_Result.getString("radius");
                                LoginData.executive_login=jsonObject_Result.getString("executive_login");
                                LoginData.city_id=jsonObject_Result.getString("city_id");


                                LoginData.verify_email=jsonObject_Result.getString("verify_email");
                                LoginData.address=jsonObject_Result.getString("address");
                                LoginData.latitude=jsonObject_Result.getString("latitude");

                                LoginData.longitude=jsonObject_Result.getString("longitude");
                                LoginData.ip_address=jsonObject_Result.getString("ip_address");
                                LoginData.os=jsonObject_Result.getString("os");

                              /*  setSharedPrefLogin(id,userName,userEmail,userMobileNo,userPassword,userTocken,userOtp,userStatus,created,modified,categories,radius,
                                        executive_login,city_id,verify_email,address,latitude,longitude,ip_address,os);
*/
                                Intent intent_n=new Intent(RegistrationActivity.this,OtpVerificationActivity.class);
                               // intent_n.putExtra("ID",id);
                                startActivity(intent_n);
                                finish();


                            }else {
                                CommonUI.showAlert(RegistrationActivity.this, getResources().getString(R.string.app_name), jsonObject.getString("message_text"));
                              /*  JSONObject jsonObjectError=new JSONObject(jsonObject.getString("message_text"));
                                //  JSONObject jsonObject1=new JSONObject();
                                if (jsonObjectError.getString("userMobileNo").equalsIgnoreCase("[\"Mobile number already taken. Try another mobile number.\"]")){

                                    CommonUI.showAlert(RegistrationActivity.this,"Picker Online","Mobile number already taken. Try another mobile number");
                                }
                                else if (jsonObjectError.getString("userName").equalsIgnoreCase("[\"Name must contain only letters (a-z)\"]")){
                                    CommonUI.showAlert(RegistrationActivity.this,"Picker Online","Name must contain only letters (a-z)");

                                }
                                else if (jsonObjectError.getString("userEmail").equalsIgnoreCase("[\"Email address already taken. Try another email address.\"]")){
                                    CommonUI.showAlert(RegistrationActivity.this,"Picker Online","Email address already taken. Try another email address");
                                }*/
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();


                        Log.e("ERORRRRRRR",""+error);


                    }
                }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("userName",edt_Name.getText().toString().trim());
                params.put("userEmail",edt_Email.getText().toString().trim());
                params.put("userMobileNo",edt_Mobile.getText().toString().trim());
                return params;
            }

        };

        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);

        progressDialog = new ProgressDialog(RegistrationActivity.this);
        progressDialog.setMessage("Please Wait....");
        progressDialog.setProgressStyle(progressDialog.STYLE_SPINNER);
        progressDialog.show();



    }


    private boolean validation() {


        String name=edt_Name.getText().toString().trim();
        String phone=edt_Mobile.getText().toString().trim();
        String email=edt_Email.getText().toString().trim();
        if (name.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter valid User Name");
        else if (phone.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter valid  Mobile  Number.");
        else if (phone.length()<10)
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter valid  Mobile  Number.");
        else if (phone.length()>10)
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter valid  Mobile  Number.");
        else if (!(PatternsCompat.EMAIL_ADDRESS.matcher(email).matches()))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter valid Email ID");
        else
            return true;

        return false;
    }

    private void setSharedPrefLogin( String id,String userName,String userEmail, String userMobileNo, String userPassword, String userTocken, String userOtp,String userStatus, String created,String modified,String categories,String radius,String executive_login, String city_id,String verify_email, String address, String latitude, String longitude, String ip_address, String os) {
        sharedpreferences = getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putString(Constants.KEY_USERID, id);
        editor.putString(Constants.KEY_USERNAME, userName);
        editor.putString(Constants.KEY_USEREMAIL, userEmail);
        editor.putString(Constants.KEY_USERMOBILE,userMobileNo);
        editor.putString(Constants.KEY_USERPASSWORD, userPassword);
        editor.putString(Constants.KEY_USERTOCKEN, userTocken);
        editor.putString(Constants.KEY_USEROTP,userOtp);
        editor.putString(Constants.KEY_USERSTATUS,userStatus);
        editor.putString(Constants.KEY_USERCREATED,created);
        editor.putString(Constants.KEY_USERMODIFIED,modified);
        editor.putString(Constants.KEY_USERCATEGORIES,categories);
        editor.putString(Constants.KEY_USERRADIUS,radius);
        editor.putString(Constants.KEY_USEREXECUTIVELOGIN, executive_login);
        editor.putString(Constants.KEY_USERCITYID,city_id);
        editor.putString(Constants.KEY_USERVERIFYMAIL,verify_email);
        editor.putString(Constants.KEY_USERADDRESS,address);
        editor.putString(Constants.KEY_USERLAT,latitude);
        editor.putString(Constants.KEY_USERLONG,longitude);
        editor.putString(Constants.KEY_USERIP,ip_address);
        editor.putString(Constants.KEY_USEROS,os);

        editor.commit();

    }
}
