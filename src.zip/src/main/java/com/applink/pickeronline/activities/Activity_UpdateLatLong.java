package com.applink.pickeronline.activities;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applink.pickeronline.R;
import com.applink.pickeronline.models.Business;
import com.applink.pickeronline.utils.CommonUI;
import com.applink.pickeronline.utils.Constants;
import com.applink.pickeronline.utils.GPSTracker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by rahul on 24/3/18.
 */

public class Activity_UpdateLatLong extends AppCompatActivity {
    private TextView mLat,name,tital,city,pincode,area,mobile;
    String iUserId, tokan;
    private Button mBtnUpdate;
    SharedPreferences sharedpreferences;
    GPSTracker gps;
    double latitude ;
    double longitude;
    ProgressDialog progressDialog;
    String buss_id;
    private LinearLayout img_backArrow;
    private ArrayList<Business>businessArrayList;
    int pos;
    private RelativeLayout mBtngetLatLong;



    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lay_update_latlong);
        init();


        gps = new GPSTracker(Activity_UpdateLatLong.this,Activity_UpdateLatLong.this);
        getCurrentLatLong();

       // mLat.setText(latitude+","+longitude);
       // mLong.setText(longitude+"");
        mBtnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatelatlong();
            }
        });
        img_backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        mBtngetLatLong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCurrentLatLong();
                mLat.setText(latitude+" , "+longitude);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void init() {
        sharedpreferences = getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getString(Constants.KEY_USERID, "");
        tokan = sharedpreferences.getString(Constants.KEY_USERTOCKEN, "");
        businessArrayList= (ArrayList<Business>) getIntent().getSerializableExtra("BUSS_ID");
        pos=getIntent().getIntExtra("pos",1);
        mLat=findViewById(R.id.txt_lat);
        mBtnUpdate=findViewById(R.id.btn_Update);
        img_backArrow=findViewById(R.id.img_backArrow);
        name=findViewById(R.id.txt_name);
        tital=findViewById(R.id.txt_owner);
        city=findViewById(R.id.txt_city);
        pincode=findViewById(R.id.txt_PinCode);
        area=findViewById(R.id.txt_Address);
        mobile=findViewById(R.id.txt_mobile);
        mBtngetLatLong=findViewById(R.id.getLatLong);
        buss_id=businessArrayList.get(pos).getID();
        name.setText(businessArrayList.get(pos).getTitle());
        tital.setText(businessArrayList.get(pos).getOwner());
        city.setText(businessArrayList.get(pos).getCity());
        pincode.setText(businessArrayList.get(pos).getPincode());
        area.setText(businessArrayList.get(pos).getArea());
        mobile.setText(businessArrayList.get(pos).getMobile());

    }
    private void getCurrentLatLong(){
        if (gps.canGetLocation()) {

            latitude = gps.getLatitude();
            longitude = gps.getLongitude();
            //LatLng sydney = new LatLng(latitude, longitude);
            Log.e("CurrentaaaaaaaaaaT:-",""+latitude+","+longitude);

        }
    }

    public void updatelatlong(){
        String url = Constants.MAIN_URL + "api/executive/business-set-latlong";
        RequestQueue requestQueue = Volley.newRequestQueue(Activity_UpdateLatLong.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                int msg_Code;
                Log.e("rrrrrwwwwwwsssss",""+response);
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    msg_Code=jsonObject.getInt("message_code");
                    if(msg_Code==1000){
                        CommonUI.showAlert(Activity_UpdateLatLong.this,"Picker Online","Lat-long Update Successful");


                    }
                    else {
                        CommonUI.showAlert(Activity_UpdateLatLong.this,"Picker Online",jsonObject.getString("message_text"));
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<String, String>();
                String credentials = iUserId + ":" + tokan;
                String auth = "Basic "
                        + Base64.encodeToString(credentials.getBytes(),
                        Base64.NO_WRAP);
                headers.put("Authorization", auth);
                return headers;

            };

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("latitude", latitude+"");
                params.put("longitude",longitude+"");

                params.put("ID",buss_id);


                return params;
            }

        };
        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Please Wait....");
        progressDialog.setProgressStyle(progressDialog.STYLE_SPINNER);
        progressDialog.show();
    }


}
