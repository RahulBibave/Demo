package com.applink.pickeronline.activities;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.VoiceInteractor;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applink.pickeronline.R;
import com.applink.pickeronline.adapters.AdapterExecutive;
import com.applink.pickeronline.adapters.Categories_Adapter;
import com.applink.pickeronline.models.Business;
import com.applink.pickeronline.models.Cateories;
import com.applink.pickeronline.models.City;
import com.applink.pickeronline.utils.CommonUI;
import com.applink.pickeronline.utils.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Sunil on 03/15/2018.
 */

public class ExecutiveHomeActivity extends AppCompatActivity {
    private ProgressDialog progressDialog;
    String iUserId,tokan,city_id;
    SharedPreferences sharedpreferences;
    private ArrayList<Business>mBusinessArrayList;
    private RecyclerView mRecyclerView;
    private AdapterExecutive adapterExecutive;
    private NavigationView navigationView,navForCart;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private View navHeader;
    LinearLayout linear_main;
    SharedPreferences.Editor editor;
    ArrayList<City>cityArrayList;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_executive_home);
        init();
        if (CommonUI.isNetworkAvailable(this)){
            getCities();
        }
        else {
            CommonUI.showAlert(ExecutiveHomeActivity.this,getString(R.string.app_name),getString(R.string.network_error));
        }
        getBusinessList();
    }

    private void init() {
        sharedpreferences = getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getString(Constants.KEY_USERID, "");
        tokan=sharedpreferences.getString(Constants.KEY_USERTOCKEN,"");
        city_id=sharedpreferences.getString(Constants.KEY_USERCITYID,"");
        mRecyclerView=findViewById(R.id.recycler_executive_list);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mBusinessArrayList=new ArrayList<>();


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        setSupportActionBar(toolbar);
        navigationView.inflateMenu(R.menu.activity_home_drawer);
        navHeader = navigationView.inflateHeaderView(R.layout.lay_navigation_drawer_header);
        linear_main=(LinearLayout)findViewById(R.id.linear_main);
        setUpNavigationView();
    }


    private void setUpNavigationView() {
        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();
                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:

                        return true;

                    case R.id.nav_profile:
                        Intent intent=new Intent(ExecutiveHomeActivity.this,Activity_Profile.class);
                        startActivity(intent);

                        return true;

                    case R.id.nav_city:
                        getCities();
                        if (cityArrayList==null||cityArrayList.size()>1){
                            getCities();
                            showCityListAlertDialog();

                        }
                        else {
                            showCityListAlertDialog();
                        }


                        break;


                    case R.id.nav_logout:
                        logoutApplication();


                        return true;

                    default:

                }

                //Checking if the item is in checked state or not, if not make it in checked state
                if (menuItem.isChecked()) {
                    menuItem.setChecked(false);
                } else {
                    menuItem.setChecked(true);
                }
                menuItem.setChecked(true);

                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                invalidateOptionsMenu();
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                linear_main.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }

    public void getBusinessList() {
        String url = "http://pickeronline.in/mobile-api/ver-1/api/executive/business-list";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressDialog.dismiss();
                mBusinessArrayList.clear();

                int msg_Code;
                Log.e("RESPONCEEEEwwwwwwwwwEEEEEE",""+response);
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    msg_Code=jsonObject.getInt("message_code");
                    JSONArray jsonArray_Result=jsonObject.getJSONArray("message_text");
                    for (int i=0;i<jsonArray_Result.length();i++){
                        JSONObject jsonObject_Result=jsonArray_Result.getJSONObject(i);
                        String id=jsonObject_Result.getString("ID");
                        String title=jsonObject_Result.getString("title");
                        String owner=jsonObject_Result.getString("owner");
                        String address=jsonObject_Result.getString("address");
                        String city=jsonObject_Result.getString("city");
                        String pincode=jsonObject_Result.getString("pincode");
                        String mobile=jsonObject_Result.getString("mobile");
                        String area=jsonObject_Result.getString("area");

                        Business business=new Business(id,title,owner,address,city,pincode,mobile,area);
                        mBusinessArrayList.add(business);
                    }
                    adapterExecutive=new AdapterExecutive(ExecutiveHomeActivity.this,mBusinessArrayList);
                    mRecyclerView.setAdapter(adapterExecutive);
                    adapterExecutive.notifyDataSetChanged();


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }


        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<String, String>();
                String credentials = iUserId + ":" + tokan;
                String auth = "Basic "
                        + Base64.encodeToString(credentials.getBytes(),
                        Base64.NO_WRAP);
                headers.put("Authorization", auth);
                return headers;


            };

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("city_id", "12");
                params.put("category_id", "");
                params.put("user_id", iUserId);
                params.put("area_id", "");
                params.put("search_title", "");
                params.put("limit", "");
                params.put("page", "");
                Log.e("qqqqqqqqqqqqqqqqq",""+city_id+" qqqqqqqqq"+iUserId);
                return params;

            }

        };
        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
        progressDialog=new ProgressDialog(ExecutiveHomeActivity.this);
        progressDialog.setMessage("Please Wait....");
        progressDialog.setProgressStyle(progressDialog.STYLE_SPINNER);
        progressDialog.show();
    }


    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.app_name);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(Constants.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(ExecutiveHomeActivity.this, LoginActivity.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }



    private void showCityListAlertDialog() {
        final Dialog dialog = new Dialog(ExecutiveHomeActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.city_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);

        ListView listView = (ListView) dialog.findViewById(R.id.city_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {

            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> cityAdapter = new ArrayAdapter<String>(ExecutiveHomeActivity.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < Constants.cityArrayList.size(); i++) {
            choices.add(Constants.cityArrayList.get(i).getCity());
            cityAdapter.add(Constants.cityArrayList.get(i).getCity());
            cityAdapter.notifyDataSetChanged();
        }



        ArrayAdapter<String> adapter = new ArrayAdapter<String>(ExecutiveHomeActivity.this,
                R.layout.city_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String Cityid=Constants.cityArrayList.get(position).getId();
                sharedpreferences = getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
                editor = sharedpreferences.edit();
                editor.putString(Constants.KEY_USERCITYID, Cityid);
                editor.commit();

                dialog.dismiss();
            }
        });

        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }



    public void getCities(){
        String url= Constants.MAIN_URL+"api/city";
        RequestQueue requestQueue= Volley.newRequestQueue(ExecutiveHomeActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        int msg_Code;
                        Constants.cityArrayList=new ArrayList<>();

                        Log.e("RESPONCEEEEEEEEEE",""+response);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            msg_Code=jsonObject.getInt("message_code");
                            JSONArray jsonArray_Result=jsonObject.getJSONArray("message_text");
                            for (int i=0;i<jsonArray_Result.length();i++){
                                JSONObject jsonObject_Result=jsonArray_Result.getJSONObject(i);
                                String id=jsonObject_Result.getString("id");
                                String city=jsonObject_Result.getString("city");
                                String state_id=jsonObject_Result.getString("state_id");
                                String slug=jsonObject_Result.getString("slug");
                                String banner=jsonObject_Result.getString("banner");
                                String modified=jsonObject_Result.getString("modified");
                                String created=jsonObject_Result.getString("created");
                                String view_order=jsonObject_Result.getString("view_order");
                                String status=jsonObject_Result.getString("status");
                                String meta_title=jsonObject_Result.getString("meta_title");
                                String meta_description=jsonObject_Result.getString("meta_description");
                                City city1=new City(id,city,state_id,slug,banner,modified,created,view_order,status,meta_title,meta_description);
                                Constants.cityArrayList.add(city1);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.e("ERORRRRRRR",""+error);


                    }
                }){ @Override
        public Map<String, String> getHeaders() throws AuthFailureError {
            Map<String,String> headers =new HashMap< String, String >();;
            String credentials = iUserId+":"+tokan;
            String auth = "Basic "
                    + Base64.encodeToString(credentials.getBytes(),
                    Base64.NO_WRAP);
            headers.put("Authorization", auth);
            return headers;
        }

        };


        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);

    }

}