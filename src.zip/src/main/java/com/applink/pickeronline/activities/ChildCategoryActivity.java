package com.applink.pickeronline.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applink.pickeronline.R;
import com.applink.pickeronline.adapters.ChildCategories_Adapter;
import com.applink.pickeronline.adapters.SubCategories_Adapter;
import com.applink.pickeronline.models.Search;
import com.applink.pickeronline.models.SubCategories;
import com.applink.pickeronline.utils.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by rahul on 19/3/18.
 */

public class ChildCategoryActivity extends AppCompatActivity {
    private RecyclerView mRecyclerViewChildCate;
    private ChildCategories_Adapter childCategories_adapter;
    private ProgressDialog progressDialog;
    String iUserId,tokan;
    SharedPreferences sharedpreferences;
    ArrayList<Search>searchArrayList;
    String Sub_Cat_ID,city_id;
    String tital;
    TextView txt_Header;
    private LinearLayout img_backArrow;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_categories);
        init();
        Intent intent=getIntent();
        Sub_Cat_ID=intent.getStringExtra("SUBCAT_ID");
        tital=intent.getStringExtra("SUB_TITAL");
        txt_Header.setText(tital);
        getAllChild_Categories();
        img_backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void init() {
        sharedpreferences = getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getString(Constants.KEY_USERID, "");
        tokan=sharedpreferences.getString(Constants.KEY_USERTOCKEN,"");
        city_id=sharedpreferences.getString(Constants.KEY_USERCITYID,"");
        mRecyclerViewChildCate=findViewById(R.id.recycler_Child_Categories);
        mRecyclerViewChildCate.setLayoutManager(new LinearLayoutManager(this));
        txt_Header=findViewById(R.id.txt_Header);
        img_backArrow=findViewById(R.id.img_backArrow);
        searchArrayList=new ArrayList<>();

    }


    public void getAllChild_Categories(){
         String url= Constants.MAIN_URL+"api/search";
         RequestQueue requestQueue= Volley.newRequestQueue(ChildCategoryActivity.this);
         StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                      //  searchArrayList.clear();

                        int msg_Code;

                        Log.e("RESPONCEEEEEEEEEE_ChildCat",""+response);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            msg_Code=jsonObject.getInt("message_code");
                            JSONArray jsonArray_Result=jsonObject.getJSONArray("result");
                            for (int i=0;i<jsonArray_Result.length();i++){
                                JSONObject jsonObject_Result=jsonArray_Result.getJSONObject(i);
                                String ID=jsonObject_Result.getString("ID");
                                String title=jsonObject_Result.getString("title");
                                String image=jsonObject_Result.getString("image");
                                String address=jsonObject_Result.getString("address");
                                String pincode=jsonObject_Result.getString("pincode");
                                String city_name=jsonObject_Result.getString("city_name");
                                String payout_plan=jsonObject_Result.getString("payout_plan");
                                String comment=jsonObject_Result.getString("comment");
                                String rating=jsonObject_Result.getString("rating");
                                String latitude=jsonObject_Result.getString("latitude");
                                String longitude=jsonObject_Result.getString("longitude");

                                Search search=new Search(ID, title,image,address,pincode,city_name,payout_plan,comment,rating,latitude,longitude);
                                searchArrayList.add(search);
                                Log.e("sizeee",""+image);
                            }
                            childCategories_adapter=new ChildCategories_Adapter(ChildCategoryActivity.this,searchArrayList);
                            mRecyclerViewChildCate.setAdapter(childCategories_adapter);
                            childCategories_adapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Log.e("ERORRRRRRR",""+error);
                    }
                }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> headers =new HashMap< String, String >();
                String credentials = iUserId+":"+tokan;
                String auth = "Basic "
                        + Base64.encodeToString(credentials.getBytes(),
                        Base64.NO_WRAP);
                headers.put("Authorization", auth);
                return headers;

            };
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("parent_category_id",Constants.Cat_Id);
                params.put("sub_category_id",Sub_Cat_ID);
                params.put("city_id",city_id);

                return params;
            }
        };

        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
        progressDialog=new ProgressDialog(ChildCategoryActivity.this);
        progressDialog.setMessage("Please Wait....");
        progressDialog.setProgressStyle(progressDialog.STYLE_SPINNER);
        progressDialog.show();

    }
}
