package com.applink.pickeronline.activities;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v4.util.PatternsCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applink.pickeronline.R;
import com.applink.pickeronline.adapters.Categories_Adapter;
import com.applink.pickeronline.models.Cateories;
import com.applink.pickeronline.utils.CommonUI;
import com.applink.pickeronline.utils.Constants;
import com.applink.pickeronline.utils.GPSTracker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by rahul on 22/3/18.
 */

public class Activity_Profile extends AppCompatActivity {
    private EditText edt_Name,edt_mobile,edt_email,edt_address;
    private TextView edt_categories,txt_city;
    String iUserId, tokan;
    private Button mBtnUpdate;
    SharedPreferences sharedpreferences;
    GPSTracker gps;
    double latitude ;
    double longitude;
    ProgressDialog progressDialog;
    ArrayList<Cateories>listOFCategories;
    ArrayList<String> multiselecetd_list;
    String cat_name="";
    String cat_id="";
    String city_id;
    SharedPreferences.Editor editor;
    private LinearLayout img_backArrow;
    String name,mobile,email,address,city,cate;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        gps = new GPSTracker(Activity_Profile.this,Activity_Profile.this);
        getCurrentLatLong();
        init();
        multiselecetd_list=new ArrayList<>();
        getAllCategories();
        edt_categories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                multiselecetd_list.clear();
                cat_name="";
                cat_id="";
                if (listOFCategories.size()>0||listOFCategories==null){
                    getAllCategories();
                    showCategoryList();
                }
                else {
                    showCategoryList();
                }

            }
        });
        mBtnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()){
                    updateProfile();
                }

            }
        });

        txt_city.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCityListAlertDialog();
            }
        });

        img_backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void init() {
        sharedpreferences = getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getString(Constants.KEY_USERID, "");
        tokan = sharedpreferences.getString(Constants.KEY_USERTOCKEN, "");
        name=sharedpreferences.getString(Constants.KEY_USERNAME,"");
        mobile=sharedpreferences.getString(Constants.KEY_USERMOBILE,"");
        email=sharedpreferences.getString(Constants.KEY_USEREMAIL,"");
        address=sharedpreferences.getString(Constants.KEY_USERADDRESS,"");
        city=sharedpreferences.getString(Constants.KEY_CITY,"");
        cate=sharedpreferences.getString(Constants.KEY_CATE,"");


        edt_Name = findViewById(R.id.edt_Name);
        edt_mobile=findViewById(R.id.edt_MobileNo);
        edt_email=findViewById(R.id.edt_EmailID);
        edt_address=findViewById(R.id.edt_Address);
        edt_categories=findViewById(R.id.edt_categories);
        mBtnUpdate=findViewById(R.id.btn_Update);
        txt_city=findViewById(R.id.txt_city);
        listOFCategories=new ArrayList<>();
        img_backArrow=findViewById(R.id.img_backArrow);


        edt_Name.setText(name);
        edt_mobile.setText(mobile);
        edt_email.setText(email);
        edt_address.setText(address);
        if (cate==""||cate==null){
            edt_categories.setHint("Select Categories");
        }
        else {
            edt_categories.setHint(cate);
        }
        if (city==""||city==null){
            txt_city.setHint("Select City");
        }
        else {
            txt_city.setHint(city);
        }


    }
    private void getCurrentLatLong(){
        if (gps.canGetLocation()) {

            latitude = gps.getLatitude();
            longitude = gps.getLongitude();


            Log.e("Current LAT:-",""+latitude+","+longitude);

        }
    }


    public static String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {

                        return inetAddress.getHostAddress();
                    }
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public void updateProfile() {
        String url = Constants.MAIN_URL + "api/update-profile";
        RequestQueue requestQueue = Volley.newRequestQueue(Activity_Profile.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                int msg_Code;
                Log.e("rrrrrrrrrrrrrrsssssss",""+response);
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    msg_Code=jsonObject.getInt("message_code");
                    if(msg_Code==1000){

                        JSONObject jsonObject_Result=jsonObject.getJSONObject("message_text");

                        String id=jsonObject_Result.getString("ID");
                        String userName=jsonObject_Result.getString("userName");
                        String userEmail=jsonObject_Result.getString("userEmail");
                        String userMobileNo=jsonObject_Result.getString("userMobileNo");
                        String userPassword=jsonObject_Result.getString("userPassword");
                        String userTocken=jsonObject_Result.getString("userTocken");
                        String userOtp=jsonObject_Result.getString("userOtp");
                        String userStatus=jsonObject_Result.getString("userStatus");
                        String created=jsonObject_Result.getString("created");
                        String modified=jsonObject_Result.getString("modified");
                        String categories=jsonObject_Result.getString("categories");
                        String radius=jsonObject_Result.getString("radius");
                        String executive_login=jsonObject_Result.getString("executive_login");
                        String city_id=jsonObject_Result.getString("city_id");
                        String verify_email=jsonObject_Result.getString("verify_email");
                        String address=jsonObject_Result.getString("address");
                        String latitude=jsonObject_Result.getString("latitude");

                        String longitude=jsonObject_Result.getString("longitude");
                        String ip_address=jsonObject_Result.getString("ip_address");
                        String os=jsonObject_Result.getString("os");

                        Log.e("usernamewwww",""+userName+"----"+userEmail);

                        SharedPreferences preferences = getSharedPreferences(Constants.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        String city=txt_city.getText().toString();
                        String cate=edt_categories.getText().toString();

                        setSharedPrefLogin(id,userName,userEmail,userMobileNo,userPassword,userTocken,userOtp,userStatus,created,modified,categories,radius,
                                executive_login,city_id,verify_email,address,latitude,longitude,ip_address,os,city,cate);
                        showAlertProfile(Activity_Profile.this,"Picker Online","Profile Updated Successfully");

                    }
                    else {
                        //JSONObject jsonObjectError=new JSONObject(jsonObject.getString("message_text"));

                        CommonUI.showAlert(Activity_Profile.this,"Picker Online",jsonObject.getString("message_text"));
                      //  JSONObject jsonObject1=new JSONObject();
                     /*   if (jsonObjectError.getString("userMobileNo").equalsIgnoreCase("[\"Mobile number already taken. Try another mobile number.\"]")){

                            CommonUI.showAlert(Activity_Profile.this,"Picker Online","Mobile number already taken. Try another mobile number");
                        }
                        if (jsonObjectError.getString("userName").equalsIgnoreCase("[\"Name must contain only letters (a-z)\"]")){
                            CommonUI.showAlert(Activity_Profile.this,"Picker Online","Name must contain only letters (a-z)");

                        }
                        if (jsonObjectError.getString("userEmail").equalsIgnoreCase("[\"Email address already taken. Try another email address.\"]")){
                            CommonUI.showAlert(Activity_Profile.this,"Picker Online","Email address already taken. Try another email address");
                        }*/

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<String, String>();
                String credentials = iUserId + ":" + tokan;
                String auth = "Basic "
                        + Base64.encodeToString(credentials.getBytes(),
                        Base64.NO_WRAP);
                headers.put("Authorization", auth);
                return headers;

            };

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("userName", edt_Name.getText().toString());
                params.put("userEmail", edt_email.getText().toString());
                params.put("userMobileNo", edt_mobile.getText().toString());
                params.put("categories", cat_id);
                params.put("radius", "10");
                params.put("city_id", city_id);
                params.put("address", edt_address.getText().toString());
                params.put("latitude", latitude+"");
                params.put("longitude", longitude+"");
                params.put("ip_address", getLocalIpAddress());
                params.put("os", "Android");
                params.put("ID",iUserId);


                return params;
            }

        };
        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Please Wait....");
        progressDialog.setProgressStyle(progressDialog.STYLE_SPINNER);
        progressDialog.show();
    }

    public void getAllCategories(){
        String url= Constants.MAIN_URL+"api/category";
        RequestQueue requestQueue= Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        listOFCategories.clear();

                        int msg_Code;

                        Log.e("RESPONCEEEEEEEEEE",""+response);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            msg_Code=jsonObject.getInt("message_code");
                            JSONArray jsonArray_Result=jsonObject.getJSONArray("message_text");
                            for (int i=0;i<jsonArray_Result.length();i++){
                                JSONObject jsonObject_Result=jsonArray_Result.getJSONObject(i);
                                String id=jsonObject_Result.getString("ID");
                                String title=jsonObject_Result.getString("title");
                                String image=jsonObject_Result.getString("image");
                                Cateories cateories=new Cateories(id,title,image);
                                listOFCategories.add(cateories);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("ERORRRRRRR",""+error);


                    }
                }){ @Override
        public Map<String, String> getHeaders() throws AuthFailureError {
            Map<String,String> headers =new HashMap < String, String > ();;
            String credentials = iUserId+":"+tokan;
            String auth = "Basic "
                    + Base64.encodeToString(credentials.getBytes(),
                    Base64.NO_WRAP);
            headers.put("Authorization", auth);
            return headers;
        }

        };


        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);

    }


    public void showCategoryList(){
        final Dialog dialog = new Dialog(Activity_Profile.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.categories_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        Button ok=dialog.findViewById(R.id.btnOk);
        tvtitle.setText("Select Categories");
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });


        final ListView listView = (ListView) dialog.findViewById(R.id.city_alert_dialog_list_id);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {

            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> cityAdapter = new ArrayAdapter<String>(Activity_Profile.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < listOFCategories.size(); i++) {
            choices.add(listOFCategories.get(i).getName());
            cityAdapter.add(listOFCategories.get(i).getName());
            cityAdapter.notifyDataSetChanged();
        }



        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Profile.this,
                R.layout.city_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        listView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
                int count=listView.getCheckedItemCount();
                Log.e("Count******Selected**",""+count);
                if (checked){
                    multiselecetd_list.add(String.valueOf(id));
                    cat_name=cat_name+","+listOFCategories.get(position).getName();
                    cat_id=cat_id+","+listOFCategories.get(position).getId();
                    Log.e("CAT_____ID**********",""+cat_name);
                    if (cat_name.equalsIgnoreCase("")){

                    }else {
                        cat_name = cat_name.startsWith(",") ? cat_name.substring(1) : cat_name;
                        cat_id = cat_id.startsWith(",") ? cat_id.substring(1) : cat_id;

                        edt_categories.setText(cat_name);
                    }

                }else {

                    for (int i=0;i<multiselecetd_list.size();i++){
                        long tempID= Long.parseLong(multiselecetd_list.get(i).toString());
                     if (id == tempID){
                         multiselecetd_list.remove(i);
                     }
                    }


                }

                for (int i=0;i<multiselecetd_list.size();i++){
                   // Log.e("MultiSeleceteddddddddddd_items***********",""+multiselecetd_list.get(i).toString());
                }



            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                return true;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                try {
                    dialog.dismiss();
                }catch ( IllegalArgumentException e){
                    e.printStackTrace();
                }


            }
        });


        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    private void showCityListAlertDialog() {
        final Dialog dialog = new Dialog(Activity_Profile.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.city_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);


        ListView listView = (ListView) dialog.findViewById(R.id.city_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {

            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> cityAdapter = new ArrayAdapter<String>(Activity_Profile.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < Constants.cityArrayList.size(); i++) {
            choices.add(Constants.cityArrayList.get(i).getCity());
            cityAdapter.add(Constants.cityArrayList.get(i).getCity());
            cityAdapter.notifyDataSetChanged();
        }



        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Profile.this,
                R.layout.city_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                txt_city.setText(Constants.cityArrayList.get(position).getCity());
                city_id=Constants.cityArrayList.get(position).getId();

                dialog.dismiss();
            }
        });

        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    private void setSharedPrefLogin( String id,String userName,String userEmail, String userMobileNo, String userPassword, String userTocken, String userOtp,String userStatus, String created,String modified,String categories,String radius,String executive_login, String city_id,String verify_email, String address, String latitude, String longitude, String ip_address, String os,String city,String cate) {
        sharedpreferences = getSharedPreferences(Constants.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putString(Constants.KEY_USERID, id);
        editor.putString(Constants.KEY_USERNAME, userName);
        editor.putString(Constants.KEY_USEREMAIL, userEmail);
        editor.putString(Constants.KEY_USERMOBILE,userMobileNo);
        editor.putString(Constants.KEY_USERPASSWORD, userPassword);
        editor.putString(Constants.KEY_USERTOCKEN, userTocken);
        editor.putString(Constants.KEY_USEROTP,userOtp);
        editor.putString(Constants.KEY_USERSTATUS,userStatus);
        editor.putString(Constants.KEY_USERCREATED,created);
        editor.putString(Constants.KEY_USERMODIFIED,modified);
        editor.putString(Constants.KEY_USERCATEGORIES,categories);
        editor.putString(Constants.KEY_USERRADIUS,radius);
        editor.putString(Constants.KEY_USEREXECUTIVELOGIN, executive_login);
        editor.putString(Constants.KEY_USERCITYID,city_id);
        editor.putString(Constants.KEY_USERVERIFYMAIL,verify_email);
        editor.putString(Constants.KEY_USERADDRESS,address);
        editor.putString(Constants.KEY_USERLAT,latitude);
        editor.putString(Constants.KEY_USERLONG,longitude);
        editor.putString(Constants.KEY_USERIP,ip_address);
        editor.putString(Constants.KEY_USEROS,os);
        editor.putString(Constants.KEY_CITY,city);
        editor.putString(Constants.KEY_CATE,cate);

        editor.commit();

    }

    private boolean validation() {


        String name=edt_Name.getText().toString().trim();
        String phone=edt_mobile.getText().toString().trim();
        String email=edt_email.getText().toString().trim();
        String address=edt_address.getText().toString().trim();
        String city=txt_city.getText().toString();
        String cate=edt_categories.getText().toString();

        if (name.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter valid User Name");
        else if (phone.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter Mobile No.");
        else if (phone.length()<10)
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter Valid Mobile No.");
        else if (!(PatternsCompat.EMAIL_ADDRESS.matcher(email).matches()))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter Valid Email Address.");
        else if (address.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter Address.");
        else if (cate.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Categories");
        else if (city.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select City .");
        else
            return true;

        return false;
    }


    public  void showAlertProfile(Context context , String title, String msg){

        final Dialog dialog = new Dialog(Activity_Profile.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.layout_custom_alert_dialog_profile);
        TextView txtContent=dialog.findViewById(R.id.tvCustomAlertContent);
        TextView txtTitle=dialog.findViewById(R.id.tvCustomAlertTitle);
        txtTitle.setText(title);
        txtContent.setText(msg);

        Button no =dialog.findViewById(R.id.btn_No);

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Activity_Profile.this,MainActivity.class);
                startActivity(intent);
                dialog.dismiss();
                finish();

                //  onBackPressed();
                finish();
            }
        });

        dialog.show();




    }


}







