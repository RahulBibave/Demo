package com.applink.pickeronline.models;

import java.io.Serializable;

/**
 * Created by rahul on 24/3/18.
 */

public class Business implements Serializable {
    String ID,title,owner,address,city,pincode,mobile,area;

    public Business() {
    }

    public Business(String ID, String title, String owner, String address, String city, String pincode, String mobile, String area) {
        this.ID = ID;
        this.title = title;
        this.owner = owner;
        this.address = address;
        this.city = city;
        this.pincode = pincode;
        this.mobile = mobile;
        this.area = area;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
