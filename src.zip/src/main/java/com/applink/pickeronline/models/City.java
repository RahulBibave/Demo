package com.applink.pickeronline.models;

import java.io.Serializable;

/**
 * Created by rahul on 21/3/18.
 */

public class City implements Serializable {
    String id,city,state_id,slug,banner,modified,created,view_order,status,meta_title,meta_description;

    public City() {
    }

    public City(String id, String city, String state_id, String slug, String banner, String modified, String created, String view_order, String status, String meta_title, String meta_description) {
        this.id = id;
        this.city = city;
        this.state_id = state_id;
        this.slug = slug;
        this.banner = banner;
        this.modified = modified;
        this.created = created;
        this.view_order = view_order;
        this.status = status;
        this.meta_title = meta_title;
        this.meta_description = meta_description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState_id() {
        return state_id;
    }

    public void setState_id(String state_id) {
        this.state_id = state_id;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getBanner() {
        return banner;
    }

    public void setBanner(String banner) {
        this.banner = banner;
    }

    public String getModified() {
        return modified;
    }

    public void setModified(String modified) {
        this.modified = modified;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getView_order() {
        return view_order;
    }

    public void setView_order(String view_order) {
        this.view_order = view_order;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMeta_title() {
        return meta_title;
    }

    public void setMeta_title(String meta_title) {
        this.meta_title = meta_title;
    }

    public String getMeta_description() {
        return meta_description;
    }

    public void setMeta_description(String meta_description) {
        this.meta_description = meta_description;
    }
}
