package com.applink.pickeronline.models;

import java.io.Serializable;

/**
 * Created by rahul on 20/3/18.
 */

public class Search implements Serializable {
    String ID, title,image,address,pincode,city_name,payout_plan,comment,rating,latitude,longitude;

    public Search(String ID, String title, String image, String address, String pincode, String city_name, String payout_plan, String comment, String rating, String latitude, String longitude) {
        this.ID = ID;
        this.title = title;
        this.image = image;
        this.address = address;
        this.pincode = pincode;
        this.city_name = city_name;
        this.payout_plan = payout_plan;
        this.comment = comment;
        this.rating = rating;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getPayout_plan() {
        return payout_plan;
    }

    public void setPayout_plan(String payout_plan) {
        this.payout_plan = payout_plan;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
}
