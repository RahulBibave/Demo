package com.applink.pickeronline.models;

/**
 * Created by Sunil on 3/10/2018.
 */

public class Cateories {

    String id;
    String Name;
    String image;

    public Cateories(String id, String name, String image) {
        this.id = id;
        this.Name = name;
        this.image = image;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
