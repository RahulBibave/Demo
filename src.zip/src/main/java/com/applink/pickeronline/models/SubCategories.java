package com.applink.pickeronline.models;

/**
 * Created by Sunil on 3/12/2018.
 */

public class SubCategories {

    String SubCat_id;
    String sub_CatName;
    String sub_Cat_img;


    public SubCategories(String subCat_id, String sub_CatName, String sub_Cat_img) {
        SubCat_id = subCat_id;
        this.sub_CatName = sub_CatName;
        this.sub_Cat_img = sub_Cat_img;
    }

    public String getSubCat_id() {
        return SubCat_id;
    }

    public void setSubCat_id(String subCat_id) {
        SubCat_id = subCat_id;
    }

    public String getSub_CatName() {
        return sub_CatName;
    }

    public void setSub_CatName(String sub_CatName) {
        this.sub_CatName = sub_CatName;
    }

    public String getSub_Cat_img() {
        return sub_Cat_img;
    }

    public void setSub_Cat_img(String sub_Cat_img) {
        this.sub_Cat_img = sub_Cat_img;
    }
}
