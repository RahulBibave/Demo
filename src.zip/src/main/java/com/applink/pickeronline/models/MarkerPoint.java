package com.applink.pickeronline.models;

import java.io.Serializable;

public class MarkerPoint implements Serializable {
    String latlong;

    public MarkerPoint(String latlong) {
        this.latlong = latlong;
    }

    public String getLatlong() {
        return latlong;
    }

    public void setLatlong(String latlong) {
        this.latlong = latlong;
    }
}
