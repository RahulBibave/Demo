package com.applink.pickeronline.utils;

import com.applink.pickeronline.models.City;

import java.util.ArrayList;

/**
 * Created by Sunil on 3/10/2018.
 */

public class Constants {

    public static String MAIN_URL="http://pickeronline.in/mobile-api/ver-1/";

    public static final String MyPREFERENCES = "PickeronlinePrefrences";
    public final static String KEY_USERID  = "UserId";
    public final static String KEY_USERNAME  = "USERNAME";
    public final static String KEY_USEREMAIL  = "USEREMAIL";
    public final static String KEY_USERMOBILE  = "USERMOBILE";
    public final static String KEY_USERPASSWORD  = "userPassword";
    public final static String KEY_USERTOCKEN = "userTocken";
    public final static String KEY_USEROTP  = "userOtp";
    public final static String KEY_USERSTATUS  = "userStatus";
    public final static String KEY_USERCREATED  = "created";
    public final static String KEY_USERMODIFIED  = "modified";
    public final static String KEY_USERCATEGORIES  = "categories";
    public final static String KEY_USERRADIUS  = "radius";
    public final static String KEY_USEREXECUTIVELOGIN  = "executive_login";
    public final static String KEY_USERCITYID  = "city_id";
    public final static String KEY_USERVERIFYMAIL  = "verify_email";
    public final static String KEY_USERADDRESS  = "address";
    public final static String KEY_USERLAT  = "latitude";
    public final static String KEY_USERLONG = "longitude";
    public final static String KEY_USERIP  = "ip_address";
    public final static String KEY_USEROS = "os";

    public final static String KEY_CITY="city";
    public final static String KEY_CATE="cate";

    public static String Cat_Id="";
    public static String city_Id="";

    public static ArrayList<City>cityArrayList;






}
