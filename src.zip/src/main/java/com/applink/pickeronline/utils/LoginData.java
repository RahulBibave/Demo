package com.applink.pickeronline.utils;

public class LoginData {
    public static String id,userName,userEmail,userMobileNo,userPassword,userTocken,userOtp,userStatus,created,modified,categories,radius,
            executive_login,city_id,verify_email,address,latitude,longitude,ip_address,os;
}
