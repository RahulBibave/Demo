package com.applink.pickeronline.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.applink.pickeronline.R;
import com.applink.pickeronline.activities.ChildCategoryActivity;
import com.applink.pickeronline.models.SubCategories;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Sunil on 3/12/2018.
 */

public class SubCategories_Adapter extends RecyclerView.Adapter<SubCategories_Adapter.ViewHolder> {
    Context context;
    ArrayList<SubCategories> listOfSubCategories;

    public SubCategories_Adapter(Context context, ArrayList<SubCategories> listOfSubCategories) {
        this.context = context;
        this.listOfSubCategories = listOfSubCategories;
    }

    @Override
    public SubCategories_Adapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(context);
        View view=layoutInflater.inflate(R.layout.layout_sub_catgory_view,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SubCategories_Adapter.ViewHolder holder, final int position) {
        holder.txt_SubCat.setText(listOfSubCategories.get(position).getSub_CatName());

        try {
            Picasso.with(context)
                    .load("http://www.pickeronline.in/"+listOfSubCategories.get(position).getSub_Cat_img())
                    .skipMemoryCache()
                    .placeholder(R.drawable.placeholder)

                    .into(holder.img_SubCat);
        } catch (Exception ex) {

        }
        holder.img_SubCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context, ChildCategoryActivity.class);
                intent.putExtra("SUBCAT_ID",listOfSubCategories.get(position).getSubCat_id());
                intent.putExtra("SUB_TITAL",listOfSubCategories.get(position).getSub_CatName());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return listOfSubCategories.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView img_SubCat;
        TextView txt_SubCat;

        public ViewHolder(View itemView) {
            super(itemView);
            img_SubCat=(ImageView)itemView.findViewById(R.id.img_sub_categies);
            txt_SubCat=(TextView)itemView.findViewById(R.id.txt_title);
        }
    }
}
