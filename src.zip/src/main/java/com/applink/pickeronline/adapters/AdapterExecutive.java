package com.applink.pickeronline.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.applink.pickeronline.R;
import com.applink.pickeronline.activities.Activity_UpdateLatLong;
import com.applink.pickeronline.models.Business;

import java.util.ArrayList;

/**
 * Created by rahul on 24/3/18.
 */

public class AdapterExecutive extends RecyclerView.Adapter<AdapterExecutive.ViewHolder> {
    private Context mContext;
    private ArrayList<Business>mBusinessArrayList;


    public AdapterExecutive(Context mContext, ArrayList<Business> mBusinessArrayList) {
        this.mContext = mContext;
        this.mBusinessArrayList = mBusinessArrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.lay_executive_list_view,parent,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.txtTital.setText(mBusinessArrayList.get(position).getTitle());
        holder.txtPhoneNo.setText(mBusinessArrayList.get(position).getMobile());

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(mContext, Activity_UpdateLatLong.class);
                intent.putExtra("BUSS_ID",mBusinessArrayList);
                intent.putExtra("pos",position);
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mBusinessArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtTital,txtPhoneNo;
        LinearLayout linearLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            linearLayout=itemView.findViewById(R.id.linear_layout);
            txtTital=itemView.findViewById(R.id.tital);
            txtPhoneNo=itemView.findViewById(R.id.mobile);
        }
    }

}
