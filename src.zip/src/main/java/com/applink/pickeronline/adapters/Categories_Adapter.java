package com.applink.pickeronline.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.applink.pickeronline.R;
import com.applink.pickeronline.activities.SubCategoryActivity;
import com.applink.pickeronline.models.Cateories;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Sunil on 3/10/2018.
 */

public class Categories_Adapter extends RecyclerView.Adapter<Categories_Adapter.ViewHolder> {
    Context context;
    ArrayList<Cateories> listOFAllCategories;

    public Categories_Adapter(Context context, ArrayList<Cateories> listOFAllCategories) {
        this.context = context;
        this.listOFAllCategories = listOFAllCategories;
    }

    @Override
    public Categories_Adapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(context);
        View view=layoutInflater.inflate(R.layout.layout_categories_view,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(Categories_Adapter.ViewHolder holder, final int position) {
        holder.txt_Cat.setText(listOFAllCategories.get(position).getName());
        try {
            Picasso.with(context)
                    .load("http://www.pickeronline.in/"+listOFAllCategories.get(position).getImage())//product.getImages().getUrl()
                    .skipMemoryCache()
                    .placeholder(R.drawable.placeholder)

                    .into(holder.img_Cat);

        } catch (Exception ex) {

        }

        holder.img_Cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context, SubCategoryActivity.class);
                intent.putExtra("CAT_ID",listOFAllCategories.get(position).getId());
                intent.putExtra("CAT_NAME",listOFAllCategories.get(position).getName());
                context.startActivity(intent);

            }
        });


    }

    @Override
    public int getItemCount() {
        return listOFAllCategories.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView img_Cat;
        TextView txt_Cat;
        public ViewHolder(View itemView) {
            super(itemView);
            img_Cat=(ImageView)itemView.findViewById(R.id.img_categies);
            txt_Cat=(TextView)itemView.findViewById(R.id.txt_title);
        }
    }
}
