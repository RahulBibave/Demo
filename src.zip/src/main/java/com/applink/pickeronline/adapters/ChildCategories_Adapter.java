package com.applink.pickeronline.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.applink.pickeronline.R;
import com.applink.pickeronline.activities.Activity_Details;
import com.applink.pickeronline.models.Search;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by rahul on 19/3/18.
 */

public class ChildCategories_Adapter extends RecyclerView.Adapter<ChildCategories_Adapter.ViewHolder> {
    private Context mContext;
    private ArrayList<Search>mSearchArrayList;

    public ChildCategories_Adapter(Context mContext, ArrayList<Search> mSearchArrayList) {
        this.mContext = mContext;
        this.mSearchArrayList = mSearchArrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.lay_child_categories_view,parent,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
            holder.txt_Child_tital.setText(mSearchArrayList.get(position).getTitle());
            try {
                holder.ratingbar.setRating(Float.parseFloat(mSearchArrayList.get(position).getRating()));
            }catch (NumberFormatException e){
                e.printStackTrace();
            }

            try {
             Picasso.with(mContext).load("http://www.pickeronline.in/"+mSearchArrayList.get(position).getImage()).skipMemoryCache().placeholder(R.drawable.placeholder).into(holder.imgView);

              } catch (Exception ex) {
                }

        holder.linear_child.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(mContext,Activity_Details.class);
                intent.putExtra("Details",mSearchArrayList);
                intent.putExtra("pos",position);
                mContext.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return mSearchArrayList.size();
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
         ImageView imgView;
         TextView txt_Child_tital;
         RatingBar ratingbar;
         LinearLayout linear_child;

        public ViewHolder(View itemView) {
            super(itemView);
            linear_child=itemView.findViewById(R.id.linear_child);
            txt_Child_tital=itemView.findViewById(R.id.txt_Child_tital);
            imgView=itemView.findViewById(R.id.img_child_categories);
            ratingbar=itemView.findViewById(R.id.ratingbar);
        }
    }
}
